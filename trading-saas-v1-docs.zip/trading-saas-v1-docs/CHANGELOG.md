# Changelog

## 1.0.0
- Initial V1 specification
