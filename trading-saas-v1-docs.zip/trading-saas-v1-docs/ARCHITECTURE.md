# Architecture V1

- Node‑RED editor
- Design‑time validation
- No execution engine
- No deploy dependency
